package dbconnect;

import java.sql.*;

public class DatabaseConnection {
	public static Connection connection;
	public static ResultSet resultSet;
	
	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "admin");
			System.out.println("Connection Successful");
			Statement query = connection.createStatement();
			resultSet = query.executeQuery("select * from admin_details");
			while(resultSet.next()) {
				System.out.println(resultSet.getInt(0));
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getInt(2));
			}
			connection.close();
			System.out.println("Connection closed");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
