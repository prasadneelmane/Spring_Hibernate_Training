package bean;

public class HelloBean {
    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private String msg;

    public void greet(){
        System.out.println(getMsg());
    }
}
