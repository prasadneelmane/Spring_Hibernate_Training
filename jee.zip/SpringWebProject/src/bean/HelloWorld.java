package bean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class HelloWorld extends AbstractController {

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String action = request.getParameter("action");

		ModelAndView modViw = new ModelAndView();
		System.out.println("ACTION:" + action);

		switch (action) {
		case "test":
			test(modViw, request);
			break;
		}

		return modViw;
	}

	private void test(ModelAndView modViw, HttpServletRequest request) {
		System.out.println("In test method");
		testingReturnViewWithExtension(modViw, request); // This method can be in another class ideally
	}

	private void testingReturnViewWithExtension(ModelAndView modViw, HttpServletRequest request) {
		System.out.println("In testingReturnViewWithExtension......123");
		// INVOKE MODEL
		// modViw.setViewName("test.html");
		modViw.setViewName("HelloWorld.jsp");
		modViw.addObject("msg", "DataFromModel");
		System.out.println("View set");

	}

}
