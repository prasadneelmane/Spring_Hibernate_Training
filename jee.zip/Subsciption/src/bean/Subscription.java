package bean;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;

@Entity(name="Subscription")
@Table(name="SUBSCRIPTIONS", uniqueConstraints= {
		@UniqueConstraint(columnNames="ID")
})
public class Subscription implements Serializable {
	private static final long serialVersionUID = -6790693372846798580L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Integer subscriptionID;
	
	public Integer getSubscriptionID() {
		return subscriptionID;
	}

	public void setSubscriptionID(Integer subscriptionID) {
		this.subscriptionID = subscriptionID;
	}

	public String getSubscriptionName() {
		return subscriptionName;
	}

	public void setSubscriptionName(String subscriptionName) {
		this.subscriptionName = subscriptionName;
	}

	public Set<Readers> getReaders() {
		return readers;
	}

	public void setReaders(Set<Readers> readers) {
		this.readers = readers;
	}

	@Column(name = "SUBSCRIPTION_NAME", unique = true, nullable = false, length = 100)
	private String subscriptionName;
	
	@ManyToMany(mappedBy="subscriptions")
	private Set<Readers> readers;
}
