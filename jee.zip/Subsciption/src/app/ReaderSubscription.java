package app;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistryBuilder;

import bean.Readers;
import bean.Subscription;

public class ReaderSubscription {
	static SessionFactory sessionFactory = null;
	static Session session = null;
	static Readers readerOne = new Readers();
	static Readers readerTwo = new Readers();
	static Subscription subOne = new Subscription();
	static Subscription subTwo = new Subscription();

	public static void main(String[] args) {
		connect();
		session.beginTransaction();
		
		readerOne.setId(10);
		readerOne.setEmail("svb@gmail.com");
		readerOne.setName("Shivaprasad");
		
		readerTwo.setId(11);
		readerTwo.setEmail("svb@gmail.com");
		readerTwo.setName("Shivaprasad");
		
		subOne.setSubscriptionName("Entertainment");
		subTwo.setSubscriptionName("Sports");
		
		Set<Subscription> setOfReaderOne = new HashSet<Subscription>();
		setOfReaderOne.add(subOne);
		
		
	}

	public static boolean connect() {
		try {
			System.out.println("Hibernate v 4.3.x");
			Configuration config = new Configuration().configure("hibernate.cfg.xml");
			ServiceRegistryBuilder builder = new ServiceRegistryBuilder().applySettings(config.getProperties());
			sessionFactory = config.buildSessionFactory(builder.buildServiceRegistry());
			session = sessionFactory.openSession();
			System.out.println("Connected successfully");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	boolean closeSession() {
		if (session != null) {
			session.close();
			sessionFactory.close();
		}
		return true;
	}
}
