package pnr;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ControllerServlet
 */
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ServletConfig servletConfig = null;

	@Override
	public void init(ServletConfig servletConfig) throws ServletException {
		System.out.println("INIT Call");
		this.servletConfig = servletConfig;

	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ControllerServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	@Override
	// This is the controller code
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pnrNumber = request.getParameter("pnr"); // Input from form.
		System.out.println("Service Method Called : PNR Number - " + pnrNumber);
		boolean result = checkPNRStatus(pnrNumber); // invoke the model i.e business logic

		System.out.println("PNR Status : " + result);

		// passing the result to view
		request.setAttribute("Res", result);

		// Invoke the view JSP page - DYNAMIC Page
		System.out.println("Sending the control to jsp page...");
		servletConfig.getServletContext().getRequestDispatcher("/pnr.jsp").forward(request, response);

	}

	// This is the model code
	boolean checkPNRStatus(String pnrNumber) {
		return pnrNumber.equals("100");

	}

}
