package app;

import bean.CustomerService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AOPApp {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("customer.xml");
        System.out.println("Test - 1234");
        CustomerService customerService = (CustomerService) applicationContext.getBean("customerServiceProxy");
        System.out.println("*************************");
        String res = customerService.printName("FirstName/LastName");
        System.out.println("RES===========>" + res);
        System.out.println("*************************");
        customerService.printURL();
        System.out.println("*************************");
        customerService.printThrowException();
    }
}
