package bean;

import net.sf.cglib.proxy.MethodProxy;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import java.lang.reflect.Method;
import java.util.Arrays;


public class HijackAround implements MethodInterceptor {
    public Object invoke(MethodInvocation methodInvocation) {
        Object result = null;
        System.out.println("Method Name :" + methodInvocation.getMethod().getName());
        System.out.println("Method Arguments :" + Arrays.toString(methodInvocation.getArguments()));
        System.out.println("InterceptAroundMethod : Before advice activity");

        try {
            //Proceed to original method call
            result = methodInvocation.proceed();
            System.out.println("InterceptAroundMethod : After advice activity");
            System.out.println("RESULT:" + result);
            if (result instanceof String) {
                return ((String) result).toUpperCase();
            }
            return result;
        } catch (Throwable e) {
            System.out.println("InterceptAroundMethod : When Exception thrown:");
            return result;
        }
    }
}
